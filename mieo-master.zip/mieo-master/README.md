# mieo

🐱 A simple, fast, and universality command line tools.

# Usage

```
npm install -g mieo
mieo -h
```

### Create a project

```
mieo init demo
```

# Template List

+ [egg-mongoo-ts](https://github.com/seymoe/mieotpl-egg-mongoo-ts.git) A Template build with Eggjs, Mongoose and TypeScript.
